# SYMCOM Engineers Website — Free Hosting Setup (GitHub Pages)

Your site is ready in this folder: `index.html` + an `assets/` folder with
the logo and product photos pulled straight from your catalogue. Total
ongoing cost: **₹0**.

## What's already done
- Logo, EMU, dU/Dt choke filter, and factory photos pulled from your catalogue
- Contact details (phone, email, address) filled in from the catalogue
- POWERGRID / ABB / GE Vernova listed as clients
- Mobile-responsive layout, tested down to phone width

## What you still need to do (~20 minutes, no cost)

### 1. Create a free GitHub account
Go to github.com → Sign up (use your business email, e.g. marketing@symcom.in).

### 2. Create a new repository
- Click "New repository"
- Name it exactly: `symcomengineers.github.io`
  (this exact naming pattern is what makes GitHub host it for free)
- Set it to **Public**
- Don't initialize with a README

### 3. Upload your files
- On the new repo page, click "uploading an existing file"
- Drag in `index.html` and the entire `assets` folder (keep the folder
  structure — assets/logo.png, assets/emu-full-unit.jpg, etc. must stay
  inside a folder called `assets`)
- Commit the changes

### 4. Turn on GitHub Pages
- Go to repo Settings → Pages
- Under "Branch", select `main` and `/ (root)`, click Save
- Wait 1–2 minutes — your site will go live at:
  **https://symcomengineers.github.io**

That's it. No domain fees, no hosting fees, no expiry.

## The contact form (optional, also free)
The enquiry form on the Contact section needs a free form-handling
service to actually deliver emails, since GitHub Pages can't run
backend code. Easiest free option:

1. Go to formspree.io → sign up free (50 submissions/month free,
   plenty for a micro business)
2. Create a new form, get your form endpoint (looks like
   `https://formspree.io/f/abc123`)
3. Open `index.html`, find the line:
   `<form action="https://formspree.io/f/your-form-id" method="POST">`
   and replace `your-form-id` with your real Formspree ID
4. Re-upload the updated `index.html` to GitHub

Until you do this, visitors should just call or email you directly —
both are already live and working on the site.

## Later, if you want a custom domain (optional, ~₹500-900/year)
Your catalogue already shows the intended domain `symcomengineers.com`.
Whenever you're ready to pay for that:
1. Buy the domain from Namecheap, GoDaddy India, or similar
2. Point its DNS to GitHub Pages (GitHub's docs walk through this:
   docs.github.com → search "custom domain GitHub Pages")
3. Your free `symcomengineers.github.io` site keeps working in the
   meantime — nothing breaks, you just add a nicer address on top

## Updating the site later
Any time you want to change text, add a product, or swap a photo:
edit `index.html` directly in GitHub (click the file → pencil icon →
edit → commit), or come back here and I can make the edits and give
you the updated file to re-upload.
